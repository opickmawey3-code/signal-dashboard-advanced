import React, { useEffect, useState, useRef } from 'react';

/**
 * SignalDashboard — Advanced (Technical analysis + Scalping)
 * - SMA(10)/SMA(50) crossover, RSI(14) confirmation
 * - Scalping mode: faster polling (tick mode) with configurable sensitivity
 * - Data source: Twelve Data REST (apiKey) OR mock fallback
 * - History/logging + Win rate calculation
 *
 * Notes:
 * - For production use, prefer a WebSocket or broker API for ticks (Twelve Data has rate limits).
 * - If you deploy to Vercel, set VITE_TWELVE_API_KEY in Environment Variables and it will be used.
 */

function sma(arr, period){
  if(!arr || arr.length < period) return null;
  const slice = arr.slice(-period);
  const sum = slice.reduce((a,b)=>a+b,0);
  return sum / period;
}

function rsi(arr, period=14){
  if(!arr || arr.length < period+1) return null;
  let gains = 0, losses = 0;
  for(let i = arr.length - period; i < arr.length; i++){
    const diff = arr[i] - arr[i-1];
    if(diff > 0) gains += diff; else losses += Math.abs(diff);
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if(avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

export default function SignalDashboard(){
  // CONFIG
  const [apiKey, setApiKey] = useState(''); // optional: Twelve Data key
  const [symbol, setSymbol] = useState('XAU/USD');
  const [mode, setMode] = useState('technical'); // 'technical' | 'scalp' | 'both'
  const [pollMs, setPollMs] = useState(1000); // normal polling
  const [scalpPollMs, setScalpPollMs] = useState(250); // scalping tick polling
  const [pointSize, setPointSize] = useState(0.01);

  const [tp1, setTp1] = useState(15);
  const [tp2, setTp2] = useState(40);
  const [tp3, setTp3] = useState(55);
  const [sl, setSl] = useState(55);

  // STATE
  const [price, setPrice] = useState(null);
  const [entry, setEntry] = useState(null);
  const [signal, setSignal] = useState(null);
  const [status, setStatus] = useState('WAITING');
  const [history, setHistory] = useState([]);

  const pricesRef = useRef([]);
  const pollRef = useRef(null);

  // helper: fetch price from Twelve Data
  async function fetchPrice(){
    if(apiKey){
      try{
        const url = `https://api.twelvedata.com/price?symbol=${encodeURIComponent(symbol)}&apikey=${encodeURIComponent(apiKey)}`;
        const res = await fetch(url);
        if(!res.ok) return null;
        const j = await res.json();
        if(j && j.price) return Number(j.price);
        return null;
      }catch(e){
        console.warn('fetch error', e);
        return null;
      }
    }
    // fallback mock: random walk
    const base = 4060;
    const last = pricesRef.current.length ? pricesRef.current[pricesRef.current.length-1] : base;
    return Number((last + (Math.random() - 0.5) * (mode==='scalp' ? 1.2 : 3)).toFixed(2));
  }

  // Poller control depending on mode
  useEffect(()=>{
    if(pollRef.current){ clearInterval(pollRef.current); pollRef.current = null; }
    const interval = mode==='scalp' ? scalpPollMs : pollMs;
    const tick = async ()=>{
      const p = await fetchPrice();
      if(p !== null) setPrice(p);
    };
    tick();
    pollRef.current = setInterval(tick, interval);
    return ()=>{ if(pollRef.current) clearInterval(pollRef.current); pollRef.current=null; };
  }, [apiKey, symbol, mode, pollMs, scalpPollMs]);

  // Main analysis logic
  useEffect(()=>{
    if(price === null) return;
    pricesRef.current.push(price);
    if(pricesRef.current.length > 500) pricesRef.current.shift();

    // Technical signals
    const s10 = sma(pricesRef.current, 10);
    const s50 = sma(pricesRef.current, 50);
    const r = rsi(pricesRef.current, 14);

    // Combined rule: SMA crossover confirmed by RSI (not overbought/oversold)
    if((mode==='technical' || mode==='both') && !entry && s10 !== null && s50 !== null && r !== null){
      if(s10 > s50 && r > 40){ // bullish crossover + RSI > 40
        setSignal('BUY'); setEntry(price); setStatus('OPEN');
      } else if(s10 < s50 && r < 60){ // bearish crossover + RSI < 60
        setSignal('SELL'); setEntry(price); setStatus('OPEN');
      }
    }

    // Scalping rule: aggressive momentum based on short SMA slope
    if((mode==='scalp' || mode==='both') && !entry && pricesRef.current.length >= 5){
      const last5 = pricesRef.current.slice(-5);
      const slope = (last5[last5.length-1] - last5[0]) / last5.length;
      // if slope big enough create scalp entry
      if(slope > 0.2){ setSignal('BUY'); setEntry(price); setStatus('OPEN'); }
      else if(slope < -0.2){ setSignal('SELL'); setEntry(price); setStatus('OPEN'); }
    }

    // TP/SL checks
    if(entry && signal){
      const pips = signal==='BUY' ? (price - entry) / pointSize : (entry - price) / pointSize;
      if(pips >= tp3) closeSignal('TP3', pips);
      else if(pips >= tp2) closeSignal('TP2', pips);
      else if(pips >= tp1) closeSignal('TP1', pips);
      else if(pips <= -sl) closeSignal('SL', pips);
      setStatus(pips>=0 ? 'PROFIT' : 'LOSS');
    }

  }, [price]);

  const closeSignal = (reason, pips) => {
    const rec = { time: Date.now(), symbol, signal, entry, exit: price, resultPips: Number(pips.toFixed(2)), reason };
    setHistory(h => [...h, rec].slice(-200));
    setSignal(null); setEntry(null); setStatus('WAITING');
  }

  const winRate = ()=>{
    if(history.length===0) return 0;
    const wins = history.filter(h=>h.resultPips>0).length;
    return Math.round((wins/history.length)*1000)/10;
  }

  const profitPips = entry ? (signal==='BUY' ? (price - entry)/pointSize : (entry - price)/pointSize) : 0;

  return (
    <div className="min-h-screen bg-neutral-900 text-white p-6">
      <div className="max-w-5xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Signal Dashboard — XAU/USD (Advanced)</h1>
          <div className="text-sm text-neutral-300">Mode: <span className="font-medium">{mode}</span></div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-neutral-800 rounded-2xl p-4 shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-neutral-400">Last update</div>
                <div className="text-lg font-semibold">{price===null?'-':price}</div>
              </div>
              <div className="text-right">
                <div className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${signal==='SELL'?'bg-red-600':'bg-green-600'}`}>{signal||'NO SIGNAL'}</div>
                <div className="text-xs text-neutral-400 mt-1">Status: <span className="font-medium">{status}</span></div>
              </div>
            </div>

            <div className="mt-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-neutral-900 p-3 rounded">
                  <div className="text-xs text-neutral-400">Entry</div>
                  <div className="font-semibold">{entry||'-'}</div>
                </div>
                <div className="bg-neutral-900 p-3 rounded">
                  <div className="text-xs text-neutral-400">Current Price</div>
                  <div className="font-semibold">{price===null?'-':price}</div>
                </div>
                <div className="bg-neutral-900 p-3 rounded">
                  <div className="text-xs text-neutral-400">Profit (pips)</div>
                  <div className="font-semibold">{entry?profitPips.toFixed(1):'-'}</div>
                </div>
                <div className="bg-neutral-900 p-3 rounded">
                  <div className="text-xs text-neutral-400">Win Rate</div>
                  <div className="font-semibold">{winRate()}%</div>
                </div>
              </div>

              <div className="mt-4 flex items-center gap-3">
                <div className="flex-1 bg-neutral-700 rounded h-4 overflow-hidden">
                  <div style={{ width: entry? `${Math.min(100, Math.max(0, (profitPips/tp3)*100))}%` : '0%' }} className="h-full bg-lime-500 transition-all"></div>
                </div>
                <div className="text-xs text-neutral-300">TP Progress</div>
              </div>

              <div className="mt-4 grid grid-cols-4 gap-2 text-center">
                <div className="p-2 rounded bg-green-800">TP1<br/><span className="text-xl font-bold">{tp1}</span></div>
                <div className="p-2 rounded bg-green-700">TP2<br/><span className="text-xl font-bold">{tp2}</span></div>
                <div className="p-2 rounded bg-green-600">TP3<br/><span className="text-xl font-bold">{tp3}</span></div>
                <div className="p-2 rounded bg-neutral-700">SL<br/><span className="text-xl font-bold">{sl}</span></div>
              </div>

            </div>
          </div>

          <div className="bg-neutral-800 rounded-2xl p-4 shadow-lg">
            <div className="mb-3 text-sm text-neutral-300">Settings</div>

            <label className="text-xs text-neutral-300">Data Source (Twelve Data optional)</label>
            <input value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="PASTE_TWELVE_API_KEY_HERE" className="w-full bg-neutral-900 p-2 rounded text-sm mb-2" />

            <label className="text-xs text-neutral-300">Symbol</label>
            <input value={symbol} onChange={e=>setSymbol(e.target.value)} className="w-full bg-neutral-900 p-2 rounded text-sm mb-2" />

            <label className="text-xs text-neutral-300">Mode</label>
            <select value={mode} onChange={e=>setMode(e.target.value)} className="w-full bg-neutral-900 p-2 rounded text-sm mb-2">
              <option value="technical">Technical only</option>
              <option value="scalp">Scalping only</option>
              <option value="both">Both</option>
            </select>

            <label className="text-xs text-neutral-300">Poll interval (ms)</label>
            <input type="number" value={pollMs} onChange={e=>setPollMs(Number(e.target.value))} className="w-full bg-neutral-900 p-2 rounded text-sm mb-2" />

            <label className="text-xs text-neutral-300">Scalp poll interval (ms)</label>
            <input type="number" value={scalpPollMs} onChange={e=>setScalpPollMs(Number(e.target.value))} className="w-full bg-neutral-900 p-2 rounded text-sm mb-2" />

            <div className="mt-2 grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-neutral-300">Point size</label>
                <input type="number" step="0.0001" value={pointSize} onChange={e=>setPointSize(Number(e.target.value))} className="w-full bg-neutral-900 p-2 rounded text-sm" />
              </div>
              <div>
                <label className="text-xs text-neutral-300">Reset</label>
                <button onClick={()=>{ setHistory([]); setSignal(null); setEntry(null); setStatus('WAITING'); }} className="w-full py-2 rounded bg-zinc-700">Reset</button>
              </div>
            </div>

            <div className="mt-4 text-xs text-neutral-400">History (last 200)</div>
            <div className="mt-2 max-h-56 overflow-auto text-sm">
              {history.length===0 ? <div className="text-neutral-500">No history yet</div> : (
                history.slice().reverse().map((h,i)=>(
                  <div key={i} className="p-2 bg-neutral-900 rounded mb-1 flex justify-between">
                    <div>
                      <div className="font-medium">{h.signal} {h.symbol}</div>
                      <div className="text-xs text-neutral-400">{new Date(h.time).toLocaleString()}</div>
                      <div className="text-xs text-neutral-400">reason: {h.reason}</div>
                    </div>
                    <div className={`text-sm ${h.resultPips>0 ? 'text-lime-400' : 'text-rose-400'}`}>{h.resultPips} pips</div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-3 text-xs text-neutral-400">Notes:</div>
            <ul className="text-xs text-neutral-400 list-disc ml-4">
              <li>To enable live XAU/USD use Twelve Data API key (or your broker's API).</li>
              <li>Scalping mode uses aggressive polling — be mindful of API rate limits.</li>
              <li>If you want MT5 integration, I can provide a bridge (extra step).</li>
            </ul>

          </div>

        </div>

      </div>
    </div>
  );
}
