import React from 'react'
import SignalDashboard from './components/SignalDashboard'

export default function App(){
  return <SignalDashboard />
}
