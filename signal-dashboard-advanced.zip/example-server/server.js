/* Minimal mock server for testing: REST /price and WebSocket tick broadcast */
const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let price = 4065.83;
setInterval(()=>{
  // quick random walk
  price = Number((price + (Math.random()-0.5)*1.5).toFixed(2));
  wss.clients.forEach(c=>{ if(c.readyState===WebSocket.OPEN) c.send(JSON.stringify({ price })); });
}, 250);

app.get('/price', (req,res)=>{ res.json({ price }); });

server.listen(4000, ()=>console.log('Mock server running on http://localhost:4000 - WS ws://localhost:4000'));

