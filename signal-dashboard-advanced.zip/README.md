# Signal Dashboard Advanced

This project is an enhanced Signal Dashboard with:
- Technical analysis: SMA crossover + RSI confirmation
- Scalping mode: tick-based fast polling and momentum scalp detection
- Twelve Data integration (optional) or mock fallback

## Quickstart
1. `npm install`
2. `npm run start:mock` (optional mock server for testing)
3. `npm run dev`

## Deploy
- Push to GitHub and import to Vercel (Build: `npm run build`, Output dir: `dist`).
- For live Twelve Data integration, set `VITE_TWELVE_API_KEY` env var in Vercel or paste API key in UI.

## Notes
- Scalping uses aggressive polling — watch API rate limits.
- For MT5 integration, a bridge is needed (I can provide).
